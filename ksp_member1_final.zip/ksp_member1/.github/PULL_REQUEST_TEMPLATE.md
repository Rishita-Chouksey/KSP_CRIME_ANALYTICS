## Summary

<!-- What does this PR change and why? -->

## Checklist

- [ ] Branch is `feature/<member>-<short-description>` and targets `dev` (not `main`)
- [ ] `pytest tests/ -q` passes locally
- [ ] `ruff check .` and `ruff format --check .` pass locally
- [ ] No secrets, API keys, or `.env` values are committed
- [ ] New/changed endpoints go through `AuthMiddleware` + `auth/rbac.py` permission checks
- [ ] New/changed input parameters are validated via `security/validators.py`
- [ ] Docs updated if this changes an API, config, or deployment step (`docs/`)
- [ ] Linked to the relevant project plan item / issue

## Testing performed

<!-- Commands run, manual verification, screenshots if UI-facing -->

## Risk / rollback

<!-- Any risk to production if this ships? How would it be rolled back? -->
