import pytest

from security.validators import (
    ValidationError,
    sanitize_district_id,
    sanitize_pagination,
    validate_date_range,
)


def test_sanitize_district_id_accepts_numeric():
    assert sanitize_district_id("123") == "123"


def test_sanitize_district_id_accepts_alpha_prefixed():
    assert sanitize_district_id("BLR-1") == "BLR-1"


def test_sanitize_district_id_rejects_injection_attempt():
    with pytest.raises(ValidationError):
        sanitize_district_id("1; DROP TABLE CaseMaster")


def test_sanitize_pagination_valid():
    page, page_size = sanitize_pagination("2", "50")
    assert page == 2
    assert page_size == 50


def test_sanitize_pagination_rejects_oversized_page_size():
    with pytest.raises(ValidationError):
        sanitize_pagination(1, 10000)


def test_sanitize_pagination_rejects_non_integer():
    with pytest.raises(ValidationError):
        sanitize_pagination("one", 10)


def test_validate_date_range_valid():
    start, end = validate_date_range("2026-01-01", "2026-03-31")
    assert start.month == 1
    assert end.month == 3


def test_validate_date_range_rejects_reversed_range():
    with pytest.raises(ValidationError):
        validate_date_range("2026-03-31", "2026-01-01")


def test_validate_date_range_rejects_bad_format():
    with pytest.raises(ValidationError):
        validate_date_range("01/01/2026", "2026-03-31")
