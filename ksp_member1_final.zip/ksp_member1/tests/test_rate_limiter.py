import pytest

from gateway.rate_limiter import RateLimiter, RateLimitExceeded


def test_allows_requests_within_burst_capacity():
    limiter = RateLimiter(requests_per_minute=60, burst=5)

    for _ in range(5):
        limiter.check("client_a")  # should not raise


def test_raises_once_burst_capacity_is_exhausted():
    limiter = RateLimiter(requests_per_minute=60, burst=3)

    for _ in range(3):
        limiter.check("client_b")

    with pytest.raises(RateLimitExceeded):
        limiter.check("client_b")


def test_clients_are_tracked_independently():
    limiter = RateLimiter(requests_per_minute=60, burst=1)

    limiter.check("client_c")  # exhausts client_c's single token
    limiter.check("client_d")  # client_d has its own bucket, should not raise

    with pytest.raises(RateLimitExceeded):
        limiter.check("client_c")


def test_invalid_requests_per_minute_raises():
    with pytest.raises(ValueError):
        RateLimiter(requests_per_minute=0)
