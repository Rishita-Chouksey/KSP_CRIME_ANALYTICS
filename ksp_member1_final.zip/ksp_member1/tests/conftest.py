import pytest


@pytest.fixture(autouse=True)
def _test_environment(monkeypatch):
    """Provide safe, non-placeholder env vars for every test."""
    monkeypatch.setenv("JWT_SECRET_KEY", "test-secret-key-for-unit-tests-only")
    monkeypatch.setenv("JWT_ALGORITHM", "HS256")
    monkeypatch.setenv("JWT_ISSUER", "ksp-crime-analytics")
    monkeypatch.setenv("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", "30")
    monkeypatch.setenv("JWT_REFRESH_TOKEN_EXPIRE_DAYS", "7")
    monkeypatch.setenv("DASHBOARD_READONLY_API_KEY", "test-readonly-key")
    monkeypatch.setenv("ADMIN_API_KEY", "test-admin-key")
    monkeypatch.setenv("CATALYST_PROJECT_ID", "test-project-id")
    monkeypatch.setenv("CATALYST_ENV", "development")
    monkeypatch.setenv("RATE_LIMIT_REQUESTS_PER_MINUTE", "100")
    monkeypatch.setenv("RATE_LIMIT_BURST", "20")
    monkeypatch.setenv("IP_WHITELIST", "127.0.0.1/32,10.0.0.0/8")
    monkeypatch.setenv("CORS_ALLOWED_ORIGINS", "https://ksp-dashboard.internal.gov.in")
    yield
