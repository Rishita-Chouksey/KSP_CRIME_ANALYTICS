import pytest

from auth.rbac import Permission, has_permission, require_permission


def test_viewer_can_read_but_not_generate_reports():
    assert has_permission("viewer", Permission.READ_ANALYTICS) is True
    assert has_permission("viewer", Permission.GENERATE_REPORT) is False


def test_analyst_can_generate_reports():
    assert has_permission("analyst", Permission.GENERATE_REPORT) is True
    assert has_permission("analyst", Permission.WRITE_INGESTION) is False


def test_admin_has_full_access():
    for permission in Permission:
        assert has_permission("admin", permission) is True


def test_unknown_role_has_no_permissions():
    assert has_permission("superuser", Permission.READ_CASES) is False


def test_require_permission_raises_for_insufficient_role():
    with pytest.raises(PermissionError):
        require_permission("viewer", Permission.WRITE_INGESTION)


def test_require_permission_passes_silently_when_allowed():
    require_permission("admin", Permission.WRITE_INGESTION)  # should not raise
