import time

import pytest

from auth.jwt_handler import JWTHandler, TokenExpiredError, TokenInvalidError


def test_issue_and_validate_access_token():
    handler = JWTHandler()
    token = handler.issue_access_token(subject="officer_123", role="analyst", district_scope=["BLR-01"])

    payload = handler.validate_access_token(token)

    assert payload.subject == "officer_123"
    assert payload.role == "analyst"
    assert payload.district_scope == ["BLR-01"]
    assert payload.token_id


def test_refresh_token_cannot_be_used_as_access_token():
    handler = JWTHandler()
    refresh_token = handler.issue_refresh_token(subject="officer_123")

    with pytest.raises(TokenInvalidError):
        handler.validate_access_token(refresh_token)


def test_validate_refresh_token_returns_subject():
    handler = JWTHandler()
    refresh_token = handler.issue_refresh_token(subject="officer_456")

    subject = handler.validate_refresh_token(refresh_token)

    assert subject == "officer_456"


def test_malformed_token_is_rejected():
    handler = JWTHandler()

    with pytest.raises(TokenInvalidError):
        handler.validate_access_token("not-a-real-token")


def test_expired_token_is_rejected(monkeypatch):
    monkeypatch.setenv("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", "0")
    handler = JWTHandler()
    token = handler.issue_access_token(subject="officer_789", role="viewer")

    time.sleep(1.2)

    with pytest.raises(TokenExpiredError):
        handler.validate_access_token(token)


def test_tampered_signature_is_rejected():
    handler = JWTHandler()
    token = handler.issue_access_token(subject="officer_123", role="viewer")
    tampered = token[:-2] + ("aa" if not token.endswith("aa") else "bb")

    with pytest.raises(TokenInvalidError):
        handler.validate_access_token(tampered)
