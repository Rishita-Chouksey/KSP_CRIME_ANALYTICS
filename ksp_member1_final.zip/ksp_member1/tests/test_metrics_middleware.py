from middleware.metrics_middleware import track_metrics
from monitoring.metrics import get_metrics


class _FakeRequest:
    pass


def test_track_metrics_records_success():
    @track_metrics("test_endpoint_success")
    def handler(request):
        return "ok"

    handler(_FakeRequest())
    snapshot = get_metrics().snapshot()
    assert snapshot["test_endpoint_success"]["request_count"] == 1
    assert snapshot["test_endpoint_success"]["error_count"] == 0


def test_track_metrics_records_exception_as_error():
    @track_metrics("test_endpoint_error")
    def handler(request):
        raise RuntimeError("boom")

    try:
        handler(_FakeRequest())
    except RuntimeError:
        pass

    snapshot = get_metrics().snapshot()
    assert snapshot["test_endpoint_error"]["request_count"] == 1
    assert snapshot["test_endpoint_error"]["error_count"] == 1


def test_track_metrics_uses_function_name_by_default():
    @track_metrics()
    def some_named_handler(request):
        return "ok"

    some_named_handler(_FakeRequest())
    snapshot = get_metrics().snapshot()
    assert "some_named_handler" in snapshot
