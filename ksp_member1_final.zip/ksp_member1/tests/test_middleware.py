import pytest

from auth.jwt_handler import JWTHandler
from auth.rbac import Permission
from middleware.auth_middleware import (
    AuthenticationFailed,
    AuthMiddleware,
    AuthorizationFailed,
)
from middleware.error_handler import build_error_response
from security.validators import ValidationError


class _FakeRequest:
    def __init__(self, headers):
        self.headers = headers


def test_authenticate_valid_bearer_token():
    handler = JWTHandler()
    token = handler.issue_access_token(subject="officer_1", role="viewer")
    middleware = AuthMiddleware(jwt_handler=handler)

    payload = middleware.authenticate(f"Bearer {token}")

    assert payload.subject == "officer_1"


def test_authenticate_missing_header_fails():
    middleware = AuthMiddleware()
    with pytest.raises(AuthenticationFailed):
        middleware.authenticate(None)


def test_authenticate_malformed_header_fails():
    middleware = AuthMiddleware()
    with pytest.raises(AuthenticationFailed):
        middleware.authenticate("Basic somevalue")


def test_authorize_rejects_insufficient_role():
    handler = JWTHandler()
    token = handler.issue_access_token(subject="officer_1", role="viewer")
    middleware = AuthMiddleware(jwt_handler=handler)
    payload = middleware.authenticate(f"Bearer {token}")

    with pytest.raises(AuthorizationFailed):
        middleware.authorize(payload, Permission.WRITE_INGESTION)


def test_authenticate_api_key_readonly(monkeypatch):
    middleware = AuthMiddleware()
    role = middleware.authenticate_api_key("test-readonly-key")
    assert role == "viewer"


def test_authenticate_api_key_invalid():
    middleware = AuthMiddleware()
    with pytest.raises(AuthenticationFailed):
        middleware.authenticate_api_key("not-a-real-key")


def test_error_response_status_codes():
    assert build_error_response(AuthenticationFailed("x")).status_code == 401
    assert build_error_response(AuthorizationFailed("x")).status_code == 403
    assert build_error_response(ValidationError("x")).status_code == 400
    assert build_error_response(RuntimeError("boom")).status_code == 500


def test_error_response_hides_internal_detail_for_500():
    response = build_error_response(RuntimeError("db password is hunter2"))
    assert "hunter2" not in response.body["error"]["message"]
