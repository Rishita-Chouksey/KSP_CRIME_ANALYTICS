"""
Lightweight in-memory metrics collection surfaced through the
`/api/health` endpoint and Catalyst monitoring dashboard.

Not a replacement for a full metrics backend (Prometheus/Datadog) — scoped
deliberately to what a hackathon prototype needs to demonstrate
production-mindedness: request counts, error counts, and latency percentiles.
"""

from __future__ import annotations

import threading
from bisect import insort
from dataclasses import dataclass, field


@dataclass
class _EndpointStats:
    request_count: int = 0
    error_count: int = 0
    latencies_ms: list[float] = field(default_factory=list)

    def percentile(self, pct: float) -> float:
        if not self.latencies_ms:
            return 0.0
        sorted_latencies = sorted(self.latencies_ms)
        index = min(len(sorted_latencies) - 1, int(len(sorted_latencies) * pct))
        return sorted_latencies[index]


class MetricsCollector:
    """Thread-safe, process-local metrics store. Singleton via `get_metrics()`."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._stats: dict[str, _EndpointStats] = {}

    def record_request(self, endpoint: str, duration_ms: float, is_error: bool) -> None:
        with self._lock:
            stats = self._stats.setdefault(endpoint, _EndpointStats())
            stats.request_count += 1
            if is_error:
                stats.error_count += 1
            insort(stats.latencies_ms, duration_ms)
            # Cap retained samples to avoid unbounded memory growth on long-running functions.
            if len(stats.latencies_ms) > 1000:
                stats.latencies_ms = stats.latencies_ms[-1000:]

    def snapshot(self) -> dict[str, dict[str, float]]:
        with self._lock:
            return {
                endpoint: {
                    "request_count": stats.request_count,
                    "error_count": stats.error_count,
                    "error_rate": (stats.error_count / stats.request_count) if stats.request_count else 0.0,
                    "p50_ms": stats.percentile(0.50),
                    "p95_ms": stats.percentile(0.95),
                    "p99_ms": stats.percentile(0.99),
                }
                for endpoint, stats in self._stats.items()
            }


_metrics_instance: MetricsCollector | None = None
_instance_lock = threading.Lock()


def get_metrics() -> MetricsCollector:
    global _metrics_instance
    if _metrics_instance is None:
        with _instance_lock:
            if _metrics_instance is None:
                _metrics_instance = MetricsCollector()
    return _metrics_instance
