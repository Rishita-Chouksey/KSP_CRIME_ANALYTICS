"""
Structured (JSON) logging configuration, so Catalyst's `catalyst logs`
output is machine-parseable and consistent across every module in the
platform.
"""

from __future__ import annotations

import logging
import os
from functools import cache

import structlog


def _configure_structlog() -> None:
    log_level_name = os.getenv("LOG_LEVEL", "INFO").upper()
    log_level = getattr(logging, log_level_name, logging.INFO)

    logging.basicConfig(format="%(message)s", level=log_level)

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(log_level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


_configure_structlog()


@cache
def get_logger(component: str) -> structlog.BoundLogger:
    """Return a structlog logger bound with a `component` field for filtering in log search."""
    return structlog.get_logger().bind(component=component, service="ksp-crime-analytics")
