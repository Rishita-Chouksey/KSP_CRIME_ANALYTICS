"""
Metrics middleware — records every request into the shared MetricsCollector
(monitoring/metrics.py) so `/api/health` and the Catalyst monitoring
dashboard reflect real traffic without each Member 4 handler having to call
`get_metrics().record_request()` itself.

Ordering: wrap innermost (closest to the handler) so duration reflects
handler execution time; ErrorHandlerMiddleware and LoggingMiddleware wrap
outside this. See docs/ARCHITECTURE.md for the full middleware chain order.
"""

from __future__ import annotations

import functools
import time
from collections.abc import Callable
from typing import Any

from monitoring.metrics import get_metrics


class MetricsMiddleware:
    """Wraps a handler call, recording request count/latency/error status per endpoint."""

    def __init__(self, endpoint_name: str | None = None) -> None:
        self._endpoint_name = endpoint_name

    def __call__(self, handler: Callable) -> Callable:
        endpoint = self._endpoint_name or getattr(handler, "__name__", "unknown")

        @functools.wraps(handler)
        def wrapper(request: Any, *args, **kwargs):
            started_at = time.perf_counter()
            is_error = False
            try:
                response = handler(request, *args, **kwargs)
                status_code = getattr(response, "status_code", 200)
                is_error = status_code >= 500
                return response
            except Exception:
                is_error = True
                raise
            finally:
                duration_ms = (time.perf_counter() - started_at) * 1000
                get_metrics().record_request(endpoint, duration_ms, is_error=is_error)

        return wrapper


def track_metrics(endpoint_name: str | None = None) -> Callable:
    """Decorator form: `@track_metrics("get_hotspots")` above a route handler."""
    return MetricsMiddleware(endpoint_name)
