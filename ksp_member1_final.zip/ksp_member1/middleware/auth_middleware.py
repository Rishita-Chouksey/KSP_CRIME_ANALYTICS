"""
Authentication/authorization middleware wired in front of every Catalyst
Advanced I/O Function (Core CRUD API and Analytics API, both owned by
Member 4, but secured here by Member 1's shared middleware).

Two auth modes are supported per the project plan:
  - JWT bearer tokens for officer-facing endpoints (`/api/cases`,
    `/api/analytics/*`, etc.)
  - A static read-only API key for the public districts lookup
    (`/api/districts`) and health checks.
"""

from __future__ import annotations

import functools
import hmac
from collections.abc import Callable
from typing import Any

from auth.jwt_handler import JWTHandler, TokenError
from auth.rbac import Permission, has_permission
from security.secrets_manager import SecretsManager


class AuthenticationFailed(Exception):
    """Raised when a request cannot be authenticated (401)."""


class AuthorizationFailed(Exception):
    """Raised when a request is authenticated but lacks permission (403)."""


class AuthMiddleware:
    """
    Framework-agnostic auth check that a Catalyst Advanced I/O Function
    handler calls at the top of request processing.

    Usage in a Catalyst function handler:

        auth = AuthMiddleware()
        token_payload = auth.authenticate(request.headers.get("Authorization"))
        auth.authorize(token_payload, Permission.READ_ANALYTICS)
    """

    def __init__(self, jwt_handler: JWTHandler | None = None, secrets: SecretsManager | None = None) -> None:
        self._jwt = jwt_handler or JWTHandler()
        self._secrets = secrets or SecretsManager()

    def authenticate(self, authorization_header: str | None):
        """Validate a `Authorization: Bearer <token>` header and return the token payload."""
        if not authorization_header or not authorization_header.startswith("Bearer "):
            raise AuthenticationFailed("Missing or malformed Authorization header")

        token = authorization_header.removeprefix("Bearer ").strip()
        if not token:
            raise AuthenticationFailed("Empty bearer token")

        try:
            return self._jwt.validate_access_token(token)
        except TokenError as exc:
            raise AuthenticationFailed(str(exc)) from exc

    def authenticate_api_key(self, api_key_header: str | None) -> str:
        """
        Validate a static API key against the read-only or admin key.
        Returns the resolved role ("viewer" or "admin") for downstream RBAC checks.
        """
        if not api_key_header:
            raise AuthenticationFailed("Missing API key")

        if hmac.compare_digest(api_key_header, self._secrets.get_dashboard_readonly_api_key()):
            return "viewer"
        if hmac.compare_digest(api_key_header, self._secrets.get_admin_api_key()):
            return "admin"

        raise AuthenticationFailed("Invalid API key")

    def authorize(self, token_payload, permission: Permission) -> None:
        if not has_permission(token_payload.role, permission):
            raise AuthorizationFailed(
                f"Role '{token_payload.role}' is not permitted to perform '{permission.value}'"
            )


def require_auth(permission: Permission) -> Callable:
    """
    Decorator for Catalyst Advanced I/O Function route handlers.

    Expects the decorated function's first argument to be a request-like
    object exposing `.headers` (a dict-like mapping). Attaches the resolved
    `TokenPayload` onto `request.auth` before calling the wrapped handler.

    Example (used by Member 4 in gateway/app.py):

        @require_auth(Permission.READ_CASES)
        def get_cases(request):
            district = request.auth.district_scope
            ...
    """

    def decorator(handler: Callable) -> Callable:
        @functools.wraps(handler)
        def wrapper(request: Any, *args, **kwargs):
            middleware = AuthMiddleware()
            token_payload = middleware.authenticate(request.headers.get("Authorization"))
            middleware.authorize(token_payload, permission)
            request.auth = token_payload
            return handler(request, *args, **kwargs)

        return wrapper

    return decorator
