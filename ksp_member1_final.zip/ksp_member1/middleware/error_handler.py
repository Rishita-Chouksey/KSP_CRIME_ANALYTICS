"""
Central error-handling middleware that converts internal exceptions into
consistent, safe HTTP-style error envelopes — never leaking stack traces,
secrets, or internal paths to the client, while still logging full detail
server-side for debugging via `catalyst logs`.
"""

from __future__ import annotations

import functools
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from middleware.auth_middleware import AuthenticationFailed, AuthorizationFailed
from monitoring.logger import get_logger
from security.validators import ValidationError

logger = get_logger("errors")


@dataclass(frozen=True)
class ErrorResponse:
    status_code: int
    body: dict[str, Any]


_STATUS_MAP: dict[type[Exception], int] = {
    AuthenticationFailed: 401,
    AuthorizationFailed: 403,
    ValidationError: 400,
}


def build_error_response(exc: Exception, correlation_id: str = "") -> ErrorResponse:
    status_code = _STATUS_MAP.get(type(exc), 500)
    message = str(exc) if status_code < 500 else "Internal server error"

    return ErrorResponse(
        status_code=status_code,
        body={
            "error": {
                "type": type(exc).__name__ if status_code < 500 else "InternalServerError",
                "message": message,
                "correlation_id": correlation_id,
            }
        },
    )


class ErrorHandlerMiddleware:
    """Outermost middleware layer — should wrap every route handler."""

    def __call__(self, handler: Callable) -> Callable:
        @functools.wraps(handler)
        def wrapper(request: Any, *args, **kwargs):
            correlation_id = getattr(request, "correlation_id", "")
            try:
                return handler(request, *args, **kwargs)
            except (AuthenticationFailed, AuthorizationFailed, ValidationError) as exc:
                logger.warning(
                    "request.rejected",
                    correlation_id=correlation_id,
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                )
                error = build_error_response(exc, correlation_id)
                return error
            except Exception as exc:  # noqa: BLE001 - intentional catch-all boundary
                logger.error(
                    "request.unhandled_exception",
                    correlation_id=correlation_id,
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                    exc_info=True,
                )
                error = build_error_response(exc, correlation_id)
                return error

        return wrapper
