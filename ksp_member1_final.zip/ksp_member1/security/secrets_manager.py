"""
Centralized secrets access for the KSP Crime Analytics Platform.

All secrets are sourced from environment variables (populated by Catalyst's
environment configuration in production, or a local `.env` file in
development via `python-dotenv`). Nothing is ever hardcoded, and this module
never logs secret values.
"""

from __future__ import annotations

import os
from functools import lru_cache

from dotenv import load_dotenv

load_dotenv()  # no-op in production where Catalyst injects env vars directly


class MissingSecretError(RuntimeError):
    """Raised when a required secret/environment variable is not configured."""


class SecretsManager:
    """
    Thin wrapper around environment-variable access.

    Using a class (rather than free functions) keeps a single seam for
    swapping in a real secrets backend later (e.g. Catalyst's secret store,
    HashiCorp Vault, AWS Secrets Manager) without touching call sites.
    """

    def _get_required(self, key: str) -> str:
        value = os.getenv(key)
        if not value or value.startswith("replace_with"):
            raise MissingSecretError(
                f"Environment variable '{key}' is not configured. "
                f"Copy .env.example to .env and set a real value."
            )
        return value

    def get_jwt_secret(self) -> str:
        return self._get_required("JWT_SECRET_KEY")

    def get_dashboard_readonly_api_key(self) -> str:
        return self._get_required("DASHBOARD_READONLY_API_KEY")

    def get_admin_api_key(self) -> str:
        return self._get_required("ADMIN_API_KEY")

    def get_catalyst_project_id(self) -> str:
        return self._get_required("CATALYST_PROJECT_ID")

    def get_environment(self) -> str:
        return os.getenv("CATALYST_ENV", "development")

    def is_production(self) -> bool:
        return self.get_environment() == "production"


@lru_cache(maxsize=1)
def get_secrets_manager() -> SecretsManager:
    """Module-level singleton accessor to avoid re-reading env vars repeatedly."""
    return SecretsManager()
