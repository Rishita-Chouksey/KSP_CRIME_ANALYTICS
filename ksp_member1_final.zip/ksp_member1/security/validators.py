"""
Input validation/sanitization helpers shared by every API endpoint.

These guard the boundary between untrusted client input (query params, path
params) and the DataStore/ML layers built by Member 2/3/4, so malformed or
malicious input is rejected at the gateway edge.
"""

from __future__ import annotations

import re
from datetime import date, datetime

_DISTRICT_ID_PATTERN = re.compile(r"^[A-Z]{2,4}-\d{1,3}$|^\d{1,4}$")


class ValidationError(ValueError):
    """Raised when client-supplied input fails validation."""


def sanitize_district_id(district_id: str) -> str:
    """
    Validate a district identifier against the expected KSP district-code
    format (either a numeric DistrictID or a short alphabetic code + number).
    Rejects anything that doesn't match, which blocks injection attempts via
    this parameter.
    """
    if not district_id or not _DISTRICT_ID_PATTERN.match(district_id):
        raise ValidationError(f"Invalid district_id format: {district_id!r}")
    return district_id


def sanitize_pagination(page: int | str, page_size: int | str, max_page_size: int = 200) -> tuple[int, int]:
    """Validate and clamp pagination parameters to safe bounds."""
    try:
        page_int = int(page)
        page_size_int = int(page_size)
    except (TypeError, ValueError) as exc:
        raise ValidationError("page and page_size must be integers") from exc

    if page_int < 1:
        raise ValidationError("page must be >= 1")
    if page_size_int < 1 or page_size_int > max_page_size:
        raise ValidationError(f"page_size must be between 1 and {max_page_size}")

    return page_int, page_size_int


def validate_date_range(start: str, end: str) -> tuple[date, date]:
    """Validate an ISO-8601 date range (YYYY-MM-DD), ensuring start <= end."""
    try:
        start_date = datetime.strptime(start, "%Y-%m-%d").date()
        end_date = datetime.strptime(end, "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValidationError("Dates must be in YYYY-MM-DD format") from exc

    if start_date > end_date:
        raise ValidationError("start date must not be after end date")

    return start_date, end_date
