"""
Token-bucket rate limiter enforcing the project plan's requirement of
100 req/min per client in production (configurable per environment).

In the Catalyst deployment this is backed by the API Gateway's built-in rate
limiting configuration; this in-process implementation exists so:
  1. Local/dev testing works without the full gateway.
  2. A defense-in-depth check runs inside the function itself, in case the
     gateway-level limit is ever misconfigured.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass


@dataclass
class _Bucket:
    tokens: float
    last_refill: float


class RateLimitExceeded(Exception):
    """Raised when a client has exhausted its allotted request budget."""


class RateLimiter:
    """
    Simple thread-safe token-bucket limiter keyed by client identifier
    (typically the authenticated subject or source IP).
    """

    def __init__(self, requests_per_minute: int = 100, burst: int = 20) -> None:
        if requests_per_minute <= 0:
            raise ValueError("requests_per_minute must be positive")
        self._refill_rate = requests_per_minute / 60.0  # tokens per second
        self._capacity = max(burst, 1)
        self._buckets: dict[str, _Bucket] = {}
        self._lock = threading.Lock()

    def check(self, client_id: str) -> None:
        """Raise RateLimitExceeded if the client has no tokens left; otherwise consume one."""
        now = time.monotonic()
        with self._lock:
            bucket = self._buckets.get(client_id)
            if bucket is None:
                bucket = _Bucket(tokens=self._capacity - 1, last_refill=now)
                self._buckets[client_id] = bucket
                return

            elapsed = now - bucket.last_refill
            bucket.tokens = min(self._capacity, bucket.tokens + elapsed * self._refill_rate)
            bucket.last_refill = now

            if bucket.tokens < 1:
                raise RateLimitExceeded(f"Rate limit exceeded for client '{client_id}'")

            bucket.tokens -= 1

    def remaining(self, client_id: str) -> float:
        bucket = self._buckets.get(client_id)
        if bucket is None:
            return float(self._capacity)
        return bucket.tokens
