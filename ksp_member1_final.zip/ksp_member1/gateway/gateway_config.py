"""
Central configuration object for the Catalyst API Gateway layer, assembled
from environment variables at startup. Every other gateway component
(rate limiter, CORS, IP whitelist) reads from this single source of truth so
dev/prod parity is guaranteed by construction.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass(frozen=True)
class GatewayConfig:
    environment: str
    https_only: bool
    rate_limit_per_minute: int
    rate_limit_burst: int
    ip_whitelist: list[str] = field(default_factory=list)
    cors_allowed_origins: list[str] = field(default_factory=list)

    @property
    def is_production(self) -> bool:
        return self.environment == "production"


def load_gateway_config() -> GatewayConfig:
    ip_whitelist_raw = os.getenv("IP_WHITELIST", "127.0.0.1/32")
    cors_raw = os.getenv("CORS_ALLOWED_ORIGINS", "")

    return GatewayConfig(
        environment=os.getenv("CATALYST_ENV", "development"),
        https_only=os.getenv("CATALYST_ENV", "development") == "production",
        rate_limit_per_minute=int(os.getenv("RATE_LIMIT_REQUESTS_PER_MINUTE", "100")),
        rate_limit_burst=int(os.getenv("RATE_LIMIT_BURST", "20")),
        ip_whitelist=[cidr.strip() for cidr in ip_whitelist_raw.split(",") if cidr.strip()],
        cors_allowed_origins=[origin.strip() for origin in cors_raw.split(",") if origin.strip()],
    )
