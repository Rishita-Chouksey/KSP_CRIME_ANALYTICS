"""
CORS policy for the KSP Crime Analytics API Gateway.

Only the configured dashboard origin(s) are allowed in production; localhost
origins are allowed in development for the Zoho Analytics / React dashboard
work Member 5 is doing.
"""

from __future__ import annotations

from gateway.gateway_config import GatewayConfig, load_gateway_config

_ALLOWED_METHODS = "GET, POST, OPTIONS"
_ALLOWED_HEADERS = "Authorization, Content-Type, X-API-Key"


def get_cors_headers(origin: str | None, config: GatewayConfig | None = None) -> dict[str, str]:
    """
    Return the CORS response headers for a given request `Origin` header.
    If the origin is not in the allowed list, no Access-Control-Allow-Origin
    header is returned, which causes browsers to block the response.
    """
    cfg = config or load_gateway_config()

    if origin and origin in cfg.cors_allowed_origins:
        return {
            "Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Methods": _ALLOWED_METHODS,
            "Access-Control-Allow-Headers": _ALLOWED_HEADERS,
            "Access-Control-Allow-Credentials": "true",
            "Vary": "Origin",
        }

    return {"Vary": "Origin"}
