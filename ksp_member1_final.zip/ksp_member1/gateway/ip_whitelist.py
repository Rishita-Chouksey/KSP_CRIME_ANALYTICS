"""
IP whitelisting for privileged (write/ingestion) endpoints.

Read-only dashboard traffic goes through JWT/API-key auth and does not need
IP restriction, but admin/ingestion endpoints used by Member 2's bulk upload
tooling are additionally restricted to known office/VPN CIDR ranges.
"""

from __future__ import annotations

import ipaddress

from gateway.gateway_config import GatewayConfig, load_gateway_config


class IPNotWhitelistedError(Exception):
    """Raised when a request originates from a non-whitelisted address."""


class IPWhitelist:
    def __init__(self, config: GatewayConfig | None = None) -> None:
        cfg = config or load_gateway_config()
        self._networks = [ipaddress.ip_network(cidr, strict=False) for cidr in cfg.ip_whitelist]

    def check(self, client_ip: str) -> None:
        try:
            address = ipaddress.ip_address(client_ip)
        except ValueError as exc:
            raise IPNotWhitelistedError(f"Malformed client IP: {client_ip!r}") from exc

        if not any(address in network for network in self._networks):
            raise IPNotWhitelistedError(f"IP address {client_ip} is not whitelisted")

    def is_allowed(self, client_ip: str) -> bool:
        try:
            self.check(client_ip)
            return True
        except IPNotWhitelistedError:
            return False
