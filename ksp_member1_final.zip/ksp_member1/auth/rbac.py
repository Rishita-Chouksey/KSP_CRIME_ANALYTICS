"""
Role-based access control definitions for the KSP Crime Analytics Platform.

Roles map to the officer hierarchy referenced in the project plan
(read-only dashboard consumers vs. admin/ingestion users), and permissions
map 1:1 onto the API surface defined in the project plan's endpoint table.
"""

from __future__ import annotations

from enum import Enum


class Role(str, Enum):
    VIEWER = "viewer"  # Read-only dashboard access (senior officers)
    ANALYST = "analyst"  # Can trigger report generation, view analytics
    ADMIN = "admin"  # Full access including ingestion endpoints
    SERVICE = "service"  # Machine-to-machine (cron functions, internal calls)


class Permission(str, Enum):
    READ_CASES = "read:cases"
    READ_ANALYTICS = "read:analytics"
    GENERATE_REPORT = "write:reports"
    READ_ALERTS = "read:alerts"
    WRITE_INGESTION = "write:ingestion"
    MANAGE_CACHE = "manage:cache"


_ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.VIEWER: frozenset(
        {
            Permission.READ_CASES,
            Permission.READ_ANALYTICS,
            Permission.READ_ALERTS,
        }
    ),
    Role.ANALYST: frozenset(
        {
            Permission.READ_CASES,
            Permission.READ_ANALYTICS,
            Permission.READ_ALERTS,
            Permission.GENERATE_REPORT,
        }
    ),
    Role.ADMIN: frozenset(
        {
            Permission.READ_CASES,
            Permission.READ_ANALYTICS,
            Permission.READ_ALERTS,
            Permission.GENERATE_REPORT,
            Permission.WRITE_INGESTION,
            Permission.MANAGE_CACHE,
        }
    ),
    Role.SERVICE: frozenset(
        {
            Permission.READ_CASES,
            Permission.READ_ANALYTICS,
            Permission.MANAGE_CACHE,
        }
    ),
}


def has_permission(role: str, permission: Permission) -> bool:
    """Return True if the given role string grants the requested permission."""
    try:
        role_enum = Role(role)
    except ValueError:
        return False
    return permission in _ROLE_PERMISSIONS.get(role_enum, frozenset())


def require_permission(role: str, permission: Permission) -> None:
    """Raise PermissionError if the role lacks the given permission."""
    if not has_permission(role, permission):
        raise PermissionError(f"Role '{role}' lacks required permission '{permission.value}'")
