"""
JWT issuance and validation for the KSP Crime Analytics Platform.

This module is owned by Member 1 (Project Lead / DevOps) and is consumed by
the API Gateway middleware (see middleware/auth_middleware.py) to authenticate
every incoming request before it reaches Member 4's Core CRUD / Analytics
Functions.
"""

from __future__ import annotations

import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

import jwt
from jwt import (
    ExpiredSignatureError,
    ImmatureSignatureError,
    InvalidAlgorithmError,
    InvalidIssuerError,
    InvalidSignatureError,
    InvalidTokenError,
)

from security.secrets_manager import SecretsManager


class TokenError(Exception):
    """Base exception for all token-related failures."""


class TokenExpiredError(TokenError):
    """Raised when a token's expiry (`exp`) claim is in the past."""


class TokenInvalidError(TokenError):
    """Raised when a token is malformed, mis-signed, or fails claim checks."""


@dataclass(frozen=True)
class TokenPayload:
    """Strongly typed representation of a decoded JWT payload."""

    subject: str
    role: str
    district_scope: list[str] = field(default_factory=list)
    issued_at: int = 0
    expires_at: int = 0
    token_id: str = ""
    raw_claims: dict[str, Any] = field(default_factory=dict)

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"


class JWTHandler:
    """
    Issues and validates JWTs used across every API Gateway endpoint.

    Design notes:
    - HS256 by default; the secret is pulled from SecretsManager (never
      hardcoded, never logged).
    - Every token carries a unique `jti` (token_id) so that, in combination
      with a revocation list (out of scope for the hackathon prototype but
      the interface is left ready in `is_revoked`), tokens can be invalidated
      before their natural expiry.
    - Access tokens and refresh tokens use different `token_use` claims so a
      refresh token can never be replayed as an access token.
    """

    def __init__(self, secrets_manager: SecretsManager | None = None) -> None:
        self._secrets = secrets_manager or SecretsManager()
        self._algorithm = os.getenv("JWT_ALGORITHM", "HS256")
        self._issuer = os.getenv("JWT_ISSUER", "ksp-crime-analytics")
        self._access_ttl_minutes = int(os.getenv("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", "30"))
        self._refresh_ttl_days = int(os.getenv("JWT_REFRESH_TOKEN_EXPIRE_DAYS", "7"))

    # ------------------------------------------------------------------
    # Issuance
    # ------------------------------------------------------------------
    def issue_access_token(
        self,
        subject: str,
        role: str,
        district_scope: list[str] | None = None,
    ) -> str:
        now = int(time.time())
        claims = {
            "sub": subject,
            "role": role,
            "district_scope": district_scope or [],
            "token_use": "access",
            "iat": now,
            "nbf": now,
            "exp": now + (self._access_ttl_minutes * 60),
            "iss": self._issuer,
            "jti": str(uuid.uuid4()),
        }
        return jwt.encode(claims, self._secrets.get_jwt_secret(), algorithm=self._algorithm)

    def issue_refresh_token(self, subject: str) -> str:
        now = int(time.time())
        claims = {
            "sub": subject,
            "token_use": "refresh",
            "iat": now,
            "nbf": now,
            "exp": now + (self._refresh_ttl_days * 86400),
            "iss": self._issuer,
            "jti": str(uuid.uuid4()),
        }
        return jwt.encode(claims, self._secrets.get_jwt_secret(), algorithm=self._algorithm)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------
    def validate_access_token(self, token: str) -> TokenPayload:
        """Decode and validate an access token, raising TokenError subclasses on failure."""
        claims = self._decode(token)
        if claims.get("token_use") != "access":
            raise TokenInvalidError("Token is not an access token")
        if self.is_revoked(claims.get("jti", "")):
            raise TokenInvalidError("Token has been revoked")
        return TokenPayload(
            subject=claims["sub"],
            role=claims.get("role", "viewer"),
            district_scope=claims.get("district_scope", []),
            issued_at=claims.get("iat", 0),
            expires_at=claims.get("exp", 0),
            token_id=claims.get("jti", ""),
            raw_claims=claims,
        )

    def validate_refresh_token(self, token: str) -> str:
        """Return the subject of a valid refresh token."""
        claims = self._decode(token)
        if claims.get("token_use") != "refresh":
            raise TokenInvalidError("Token is not a refresh token")
        return claims["sub"]

    def is_revoked(self, token_id: str) -> bool:
        """
        Hook for a revocation list backed by Catalyst DataStore or a cache.
        Returns False by default (no revocation store wired up in the
        hackathon prototype). Kept as an explicit method so Member 4 can
        wire in a `RevokedTokens` table without touching call sites.
        """
        return False

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------
    def _decode(self, token: str) -> dict[str, Any]:
        try:
            return jwt.decode(
                token,
                self._secrets.get_jwt_secret(),
                algorithms=[self._algorithm],
                issuer=self._issuer,
                options={"require": ["exp", "iat", "sub", "jti"]},
            )
        except ExpiredSignatureError as exc:
            raise TokenExpiredError("Token has expired") from exc
        except (
            InvalidSignatureError,
            InvalidAlgorithmError,
            InvalidIssuerError,
            ImmatureSignatureError,
            InvalidTokenError,
        ) as exc:
            raise TokenInvalidError(f"Token validation failed: {exc}") from exc
