# Installation Guide

## Prerequisites

- Python 3.11+
- Node.js 18+ and npm (required for the Zoho Catalyst CLI)
- A Zoho Catalyst account with access to the `ksp-crime-analytics` project
  (request access from the project lead)
- Git

## 1. Clone and enter the repository

```bash
git clone <repo-url>
cd ksp-crime-analytics
```

## 2. Install the Catalyst CLI

```bash
npm install -g zcatalyst-cli
catalyst --version
```

## 3. Bootstrap the local environment

```bash
chmod +x scripts/*.sh deployment/*.sh
./scripts/setup_env.sh
```

This will:
1. Create a Python virtual environment at `.venv/`.
2. Install everything in `requirements.txt`.
3. Copy `.env.example` to `.env` if one doesn't already exist.
4. Generate a local development JWT secret if `JWT_SECRET_KEY` is unset.

## 4. Fill in remaining secrets

Open `.env` and replace any remaining `replace_with_*` placeholders:

- `DASHBOARD_READONLY_API_KEY` / `ADMIN_API_KEY` — coordinate with the project lead;
  these are shared secrets used by the dashboard (Member 5) and ingestion tooling (Member 2).
- `CATALYST_PROJECT_ID` / `CATALYST_ORG_ID` — from the Catalyst console, Project Settings.
- `ANTHROPIC_API_KEY` — only needed if you're running Member 4's report generator locally.

## 5. Verify the install

```bash
source .venv/bin/activate
pytest tests/ -q
```

All tests should pass. If `security/secrets_manager.py` tests fail with
`MissingSecretError`, double-check `.env` has real (non-placeholder) values.

## 6. Connect to the Catalyst project (first time only)

If this is your first time working on the project, run:

```bash
./scripts/init_catalyst.sh
```

This logs you into Catalyst, links the local directory to the shared project, and
enables the DataStore, Functions, and API Gateway components.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `catalyst: command not found` | Re-run `npm install -g zcatalyst-cli`; check your npm global bin is on `PATH` |
| `MissingSecretError: JWT_SECRET_KEY` | Run `python scripts/generate_secrets.py` |
| `ModuleNotFoundError` for a project module | Ensure you're running commands from the repo root so relative imports (`auth.`, `gateway.`, etc.) resolve |
| Tests fail with permission errors on `.sh` scripts | Run `chmod +x scripts/*.sh deployment/*.sh` |
