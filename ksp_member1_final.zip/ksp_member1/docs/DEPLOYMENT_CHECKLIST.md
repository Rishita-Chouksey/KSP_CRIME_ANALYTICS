# Final Deployment Checklist — Hackathon Submission

Run through this in order. Every item should be checked before `catalyst deploy --target production`.

## 1. Code readiness

- [ ] `pytest tests/ -q` passes (36 tests, all modules)
- [ ] `ruff check .` and `ruff format --check .` pass clean
- [ ] `python deployment/integration_check.py` shows `ALL PASSED`
- [ ] No `TODO` / `FIXME` / placeholder values left in `auth/`, `gateway/`, `middleware/`, `security/`, `deployment/`, `monitoring/`
- [ ] `dev` branch is merged into `main` via a reviewed PR (not pushed directly)

## 2. Secrets & configuration

- [ ] `.env` is **not** committed (`git ls-files | grep .env` returns nothing but `.env.example`)
- [ ] Production `JWT_SECRET_KEY` is freshly generated (`python scripts/generate_secrets.py`), unique from dev, ≥ 64 bytes
- [ ] `DASHBOARD_READONLY_API_KEY` and `ADMIN_API_KEY` are rotated from any value used during development/demos
- [ ] `CATALYST_PROJECT_ID` / `CATALYST_ORG_ID` point at the production Catalyst project, not a dev sandbox
- [ ] `CORS_ALLOWED_ORIGINS` contains only the real dashboard domain — no `localhost`, no `*`
- [ ] `IP_WHITELIST` contains only real office/VPN CIDR ranges — no `0.0.0.0/0`
- [ ] All secrets are set in the Catalyst Console's environment configuration for `production` (not just local `.env`)

## 3. API Gateway

- [ ] `catalyst.json` → `environments.production.domain` is the real production domain
- [ ] `api_gateway.https_only` is `true` for production (verified by `gateway/gateway_config.py::is_production`)
- [ ] Rate limit is 100 req/min (or the value agreed with the team) in production, not the 300 req/min dev value
- [ ] CORS origin list matches Member 5's deployed dashboard URL exactly (including scheme)
- [ ] IP whitelist covers admin/ingestion endpoints only — dashboard read traffic is not blocked

## 4. Auth & RBAC

- [ ] JWT issuance is wired to the real officer identity/login flow (not a hardcoded test subject)
- [ ] Every Member 4 route handler is decorated with `@require_auth(Permission.X)` at the correct permission level (least privilege — see `docs/API_SECURITY.md` §2)
- [ ] `/api/health` remains unauthenticated (uptime monitors need it)
- [ ] `/api/districts` uses API-key auth, not JWT

## 5. Logging & monitoring

- [ ] `LOG_LEVEL=INFO` in production (not `DEBUG` — avoid noisy/verbose logs in prod)
- [ ] Spot-check one log line in `catalyst logs` to confirm `Authorization`/`X-API-Key`/`Cookie` are redacted
- [ ] `/api/health` returns `"healthy": true` after deploy
- [ ] Metrics snapshot (`monitoring/metrics.py` via `/api/health`) shows non-zero `request_count` after a smoke test

## 6. Integration

- [ ] Member 2's DataStore tables exist in the production Catalyst project and are seeded (lookup tables: `State`, `District`, `CaseCategory`, … — see `deployment/integration_check.py::EXPECTED_MEMBER2_LOOKUP_TABLES`)
- [ ] Member 3's ML modules are reachable from the `analytics-api` function and `realtime-refresh-cron` completes without error
- [ ] Member 4's route handlers are deployed as part of `core-crud-api` / `analytics-api` and pass through this repo's middleware chain
- [ ] Member 5's dashboard successfully calls `/api/health`, `/api/districts`, and one authenticated endpoint against the production URL
- [ ] End-to-end smoke test: log in → fetch a case → fetch analytics → generate a report, all through the deployed gateway

## 7. Deploy

- [ ] `./scripts/init_catalyst.sh` has been run once against the production project (first deploy only)
- [ ] `./deployment/deploy.sh production` completes with `=== Deployment to production complete ===`
- [ ] `catalyst logs --function core-crud-api --tail` shows clean startup, no unhandled exceptions
- [ ] Custom domain (if used) resolves and serves over HTTPS with a valid certificate

## 8. Rollback readiness

- [ ] `catalyst deploy:list --function core-crud-api` shows the previous known-good version
- [ ] Team knows the rollback command (`docs/DEPLOYMENT.md` → Rollback) and who is authorized to run it during the demo window

## 9. Submission artifacts

- [ ] `README.md` accurately describes current scope and setup steps
- [ ] `docs/ARCHITECTURE.md` reflects the final layer/team-member mapping
- [ ] Answer to judges' "how do you handle data privacy?" question is accurate against what's actually deployed (`docs/API_SECURITY.md` bottom section)
- [ ] Repository is set to the visibility level required by the hackathon (private/public as instructed) with collaborators added
