# Architecture Overview — Member 1 Scope in Context

This document shows how Member 1's deliverable (this repository) fits into the full
platform described in the project plan, so Members 2–5 know exactly where their code
plugs in.

## Layered architecture (from the project plan)

```
Layer 4 — Presentation      : Zoho Analytics, Folium/Leaflet map, D3.js graph   (Member 5)
Layer 3 — API & Security    : Catalyst Advanced I/O Functions + Gateway        (Member 1 + 4)
Layer 2 — Analytics & ML    : DBSCAN, ARIMA, XGBoost, NetworkX, Isolation Forest (Member 3)
Layer 1 — Data              : Catalyst DataStore + synthetic data              (Member 2)
```

Member 1 owns the **security and operational spine** of Layer 3 and the deployment
pipeline that ships all four layers to Catalyst production.

## Request flow

```
Client (dashboard / officer browser)
   │  HTTPS
   ▼
Catalyst API Gateway  ── rate limit, CORS, IP whitelist (admin routes only)
   │
   ▼
ErrorHandlerMiddleware        (middleware/error_handler.py)
   ▼
LoggingMiddleware             (middleware/logging_middleware.py)
   ▼
AuthMiddleware.authenticate() (middleware/auth_middleware.py)
   ▼
AuthMiddleware.authorize()    (RBAC check via auth/rbac.py)
   ▼
MetricsMiddleware             (middleware/metrics_middleware.py)
   ▼
Route handler                 ← owned by Member 4 (Core CRUD / Analytics API)
   │
   ▼
DataStore (Member 2) / ML modules (Member 3)
```

## Where Member 1's modules are consumed

| Module | Consumed by |
|---|---|
| `auth/jwt_handler.py` | Member 4's login/token-refresh endpoints, `middleware/auth_middleware.py` |
| `auth/rbac.py` | Every `@require_auth(...)` decorated handler Member 4 writes |
| `gateway/*` | Catalyst API Gateway configuration; also importable for local testing |
| `middleware/*` | Wraps every Advanced I/O Function handler Member 4 builds |
| `security/secrets_manager.py` | Any module needing a secret (JWT key, API keys) — including Member 4's Claude API integration, which should add its own `get_anthropic_api_key()` accessor following this same pattern |
| `security/validators.py` | Member 4's endpoint parameter parsing, before DataStore/ML calls |
| `deployment/*`, `scripts/*` | CI/CD and the shared deploy process used by the whole team |
| `monitoring/*` | Every function — structured logs and metrics feed the Catalyst monitoring dashboard and `/api/health` |

## Non-goals of this repository

This repository intentionally does **not** contain:
- DataStore table/schema definitions (Member 2)
- Synthetic data generation scripts (Member 2/3)
- ML pipeline implementations — DBSCAN, ARIMA, XGBoost, NetworkX, Isolation Forest (Member 3)
- Business-logic route handlers for `/api/cases`, `/api/analytics/*`, `/api/reports/generate` (Member 4)
- Dashboard/frontend code — Zoho Analytics config, Folium/Leaflet maps, D3.js graphs (Member 5)

Those workstreams should import from `auth/`, `gateway/`, `middleware/`, `security/`,
and `monitoring/` rather than duplicating security logic.
