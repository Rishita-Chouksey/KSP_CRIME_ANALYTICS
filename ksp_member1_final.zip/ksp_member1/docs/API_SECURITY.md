# API Security Guide

This document describes the security controls Member 1 provides for every endpoint
listed in the project plan's API design table, and how Member 4's route handlers
should use them.

## 1. Authentication

Two mechanisms, matching the `Auth` column in the project plan's endpoint table:

### JWT bearer auth (`Auth: JWT`)
Used for all officer-facing endpoints: `/api/cases`, `/api/accused/{id}`,
`/api/analytics/*`, `/api/reports/generate`, `/api/alerts/realtime`.

```python
from auth.rbac import Permission
from middleware.auth_middleware import require_auth

@require_auth(Permission.READ_ANALYTICS)
def get_hotspots(request):
    district_scope = request.auth.district_scope
    ...
```

Tokens are issued via `auth.jwt_handler.JWTHandler.issue_access_token()` after your
own login/SSO flow authenticates the officer (out of scope for this hackathon
prototype — assume an existing KSP identity provider in production).

### API key auth (`Auth: API Key`)
Used only for `/api/districts` (public reference data). Validate with
`AuthMiddleware.authenticate_api_key()`.

### No auth (`Auth: None`)
Only `/api/health`. Do not add authentication here — health checks must be reachable
by unauthenticated uptime monitors.

## 2. Authorization (RBAC)

Four roles (`auth/rbac.py`): `viewer`, `analyst`, `admin`, `service`. Each endpoint
should declare the *minimum* permission it needs — see `Permission` enum. Do not use
`admin`-level checks for read-only endpoints; this violates least privilege and makes
the demo's "role-based access" answer to judges inaccurate.

## 3. Rate limiting

Enforced at two layers:
1. **Catalyst API Gateway** (primary) — configured via `catalyst.json` /
   `gateway/gateway_config.py`, 100 req/min in production.
2. **In-process token bucket** (defense in depth) — `gateway/rate_limiter.py`.
   Call `RateLimiter.check(client_id)` at the top of a handler if you want an extra
   guard independent of gateway configuration.

## 4. CORS

Only origins listed in `CORS_ALLOWED_ORIGINS` receive
`Access-Control-Allow-Origin` in responses (`gateway/cors_config.py`). Do not set this
to `*` in production — the dashboard origin is known and fixed.

## 5. IP whitelisting

Applied to **admin/ingestion** endpoints only (bulk upload, cache management) via
`gateway/ip_whitelist.py`. Dashboard read traffic is not IP-restricted since senior
officers may access it from varying networks; JWT auth is the primary control there.

## 6. Secrets management

All secrets come from environment variables via `security/secrets_manager.py`.
Rules:
- Never commit `.env` (enforced by `.gitignore` and the deploy preflight check).
- Never log a secret value — `middleware/logging_middleware.py` redacts
  `Authorization`, `X-API-Key`, and `Cookie` headers automatically.
- Never pass a secret as a URL query parameter (query strings end up in access logs).

## 7. Error handling

`middleware/error_handler.py` ensures:
- 401 for authentication failures, 403 for authorization failures, 400 for validation
  errors — with a client-safe message.
- 500 for anything unexpected — the client only ever sees "Internal server error";
  full detail (stack trace, exception type) is logged server-side with a
  `correlation_id` for support/debugging.

## 8. Input validation

Every path/query parameter that reaches a DataStore query or ML pipeline should pass
through `security/validators.py` first (`sanitize_district_id`, `sanitize_pagination`,
`validate_date_range`). This is the primary injection-prevention control given that
Catalyst's ZCQL layer (Member 2/4) is parameterized but still expects well-formed input.

## Answering judges' security question

> "How do you handle data privacy?"

JWT auth on all officer-facing endpoints, API Gateway rate limiting, IP whitelisting on
admin endpoints, no PII in logs (headers redacted, bodies never logged), environment
variables for all secrets, and role-based access control distinguishing viewer/analyst/
admin/service roles. Deployed on Zoho Catalyst, which is ISO 27001 certified.
