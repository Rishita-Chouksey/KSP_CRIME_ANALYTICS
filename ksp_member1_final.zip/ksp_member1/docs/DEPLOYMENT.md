# Deployment Guide

## Environments

| Environment | Purpose | Rate limit | HTTPS enforced |
|---|---|---|---|
| `development` | Local/dev testing, feature branches | 300 req/min | No |
| `production` | Live demo / KSP-facing deployment | 100 req/min | Yes |

Environment-specific values live in `catalyst.json` under `environments.*` and are
overridden at runtime by the corresponding `.env` values (`CATALYST_ENV`,
`RATE_LIMIT_REQUESTS_PER_MINUTE`, etc.).

## Standard deployment flow

```bash
./deployment/deploy.sh development   # or: production
```

This script, in order:
1. Confirms the Catalyst CLI is installed and `.env` exists.
2. Installs Python dependencies.
3. Runs the full test suite (`pytest tests/`) — deployment aborts on any failure.
4. Runs `deployment/catalyst_deploy.py`, which performs preflight validation
   (see below) before invoking `catalyst deploy --target <environment>`.

## Preflight validation

Before every deploy, `deployment/catalyst_deploy.py` checks:

- ✅ Catalyst CLI is on `PATH`
- ✅ Required files exist: `catalyst.json`, `requirements.txt`, `.env.example`
- ✅ `catalyst.json` is valid JSON and declares at least one function
- ✅ `.env` is excluded from version control via `.gitignore`

If any check fails, deployment stops with a clear error message rather than
pushing a broken or insecure build.

## Manual Catalyst CLI reference

```bash
catalyst init                 # one-time project linking (see scripts/init_catalyst.sh)
catalyst serve                # run functions locally for testing
catalyst deploy                # deploy to the environment set via `catalyst environment:use`
catalyst environment:use production
catalyst logs --function analytics-api --tail
```

## Rollback

Zoho Catalyst retains previous function deployments. To roll back:

```bash
catalyst deploy:list --function <function-name>
catalyst deploy:rollback --function <function-name> --version <previous-version>
```

## Monitoring after deployment

- `GET /api/health` — liveness + dependency check (see `deployment/health_check.py`);
  no auth required, safe for uptime monitors.
- Catalyst Console → Monitoring — request volume, error rate, and cold-start metrics
  per function.
- `catalyst logs` — structured JSON logs (see `monitoring/logger.py`); every log line
  includes a `correlation_id` that matches the one returned in error responses, so a
  user-reported error can be traced directly to its server-side log entry.

## Custom domain (production)

Configure in the Catalyst Console under **Settings → Domains**, then point the DNS
`CNAME` record to the domain Catalyst provides. Update `CORS_ALLOWED_ORIGINS` and
`cors_allowed_origins` in `catalyst.json` to match the final dashboard domain before
going live.
