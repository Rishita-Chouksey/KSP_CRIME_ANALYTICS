#!/usr/bin/env bash
# ==========================================================
# KSP Crime Analytics Platform — Deployment Script
# Usage: ./deployment/deploy.sh [development|production]
# ==========================================================
set -euo pipefail

ENVIRONMENT="${1:-development}"
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "=== KSP Crime Analytics Platform :: Deploy (${ENVIRONMENT}) ==="

if [[ "${ENVIRONMENT}" != "development" && "${ENVIRONMENT}" != "production" ]]; then
  echo "ERROR: environment must be 'development' or 'production'" >&2
  exit 1
fi

if ! command -v catalyst &> /dev/null; then
  echo "ERROR: Catalyst CLI not found. Install with: npm install -g zcatalyst-cli" >&2
  exit 1
fi

if [[ ! -f "${PROJECT_ROOT}/.env" ]]; then
  echo "ERROR: .env file not found. Copy .env.example to .env and configure it first." >&2
  exit 1
fi

echo "-> Installing Python dependencies..."
python3 -m pip install -r "${PROJECT_ROOT}/requirements.txt" --quiet

echo "-> Running test suite..."
python3 -m pytest "${PROJECT_ROOT}/tests" -q

echo "-> Running cross-module integration checks..."
python3 "${PROJECT_ROOT}/deployment/integration_check.py"

echo "-> Running deployment preflight checks..."
python3 "${PROJECT_ROOT}/deployment/catalyst_deploy.py" "${ENVIRONMENT}"

echo "=== Deployment to ${ENVIRONMENT} complete ==="
