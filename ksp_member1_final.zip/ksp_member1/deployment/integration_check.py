"""
Cross-module integration checks — the item 10 "Final Validation" pass:
confirms the API Gateway, auth, RBAC, logging, metrics, and error-handling
layers Member 1 owns actually work together end-to-end, and that the
contract points Members 2/3/4/5 plug into are present and named correctly.

This does NOT stand up a live Catalyst deployment or hit a real DataStore —
it's a fast, dependency-light smoke test you run locally or in CI right
before a deploy, so a broken integration is caught before `catalyst deploy`
rather than after.

Usage:
    python deployment/integration_check.py                # human-readable
    python deployment/integration_check.py --mode ci       # exit-code only, terse
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Callable
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Tables Member 2's synthetic-data / DataStore layer owns (see database/lookup_tables/
# generators in that workstream). Kept here only as a naming contract check — this repo
# does not implement or seed these tables itself.
EXPECTED_MEMBER2_LOOKUP_TABLES = [
    "State",
    "District",
    "UnitType",
    "Rank",
    "Designation",
    "CaseCategory",
    "GravityOffence",
    "CaseStatusMaster",
    "OccupationMaster",
    "ReligionMaster",
    "CasteMaster",
    "Act",
    "CrimeHead",
    "CrimeSubHead",
    "Section",
    "Court",
    "Unit",
    "CrimeHeadActSection",
]

# Endpoints declared in the project plan's API table that Member 4 owns; this repo
# only checks that the auth/permission contract for each is well-formed.
EXPECTED_MEMBER4_ENDPOINTS = {
    "/api/health": None,  # no auth
    "/api/districts": "api_key",
    "/api/cases": "jwt",
    "/api/accused/{id}": "jwt",
    "/api/analytics/hotspots": "jwt",
    "/api/analytics/trends": "jwt",
    "/api/reports/generate": "jwt",
    "/api/alerts/realtime": "jwt",
}


class IntegrationCheckError(Exception):
    """Raised when an integration check fails."""


def _check_gateway_config_loads() -> str:
    from gateway.gateway_config import load_gateway_config

    cfg = load_gateway_config()
    if cfg.rate_limit_per_minute <= 0:
        raise IntegrationCheckError("Gateway config: rate_limit_per_minute must be positive")
    if cfg.is_production and not cfg.https_only:
        raise IntegrationCheckError("Gateway config: production environment must enforce HTTPS")
    return (
        f"environment={cfg.environment}, rate_limit={cfg.rate_limit_per_minute}/min, "
        f"https_only={cfg.https_only}"
    )


def _check_secrets_configured() -> str:
    from security.secrets_manager import SecretsManager

    secrets = SecretsManager()
    secrets.get_jwt_secret()
    secrets.get_dashboard_readonly_api_key()
    secrets.get_admin_api_key()
    return "JWT secret and API keys resolve from environment"


def _check_jwt_issue_and_validate_roundtrip() -> str:
    from auth.jwt_handler import JWTHandler

    handler = JWTHandler()
    token = handler.issue_access_token(subject="integration-check", role="analyst", district_scope=["BLR"])
    payload = handler.validate_access_token(token)
    if payload.subject != "integration-check" or payload.role != "analyst":
        raise IntegrationCheckError("JWT roundtrip: decoded claims do not match issued claims")
    return "issue_access_token -> validate_access_token roundtrip OK"


def _check_rbac_permission_matrix() -> str:
    from auth.rbac import Permission, Role, has_permission

    if not has_permission(Role.ADMIN.value, Permission.WRITE_INGESTION):
        raise IntegrationCheckError("RBAC: admin must have WRITE_INGESTION")
    if has_permission(Role.VIEWER.value, Permission.WRITE_INGESTION):
        raise IntegrationCheckError("RBAC: viewer must NOT have WRITE_INGESTION")
    return "admin/viewer permission boundaries correct"


def _check_auth_middleware_end_to_end() -> str:
    from auth.jwt_handler import JWTHandler
    from auth.rbac import Permission
    from middleware.auth_middleware import AuthenticationFailed, AuthMiddleware, AuthorizationFailed

    jwt_handler = JWTHandler()
    token = jwt_handler.issue_access_token(subject="officer-1", role="viewer")
    middleware = AuthMiddleware(jwt_handler=jwt_handler)

    payload = middleware.authenticate(f"Bearer {token}")
    middleware.authorize(payload, Permission.READ_CASES)

    try:
        middleware.authorize(payload, Permission.WRITE_INGESTION)
        raise IntegrationCheckError("Auth middleware: viewer should not pass WRITE_INGESTION authorize()")
    except AuthorizationFailed:
        pass

    try:
        middleware.authenticate("Bearer not-a-real-token")
        raise IntegrationCheckError("Auth middleware: garbage token should fail authentication")
    except AuthenticationFailed:
        pass

    return "authenticate() -> authorize() chain enforces RBAC correctly"


def _check_error_handler_wraps_rejections() -> str:
    from middleware.auth_middleware import AuthenticationFailed
    from middleware.error_handler import build_error_response

    response = build_error_response(AuthenticationFailed("no token"), correlation_id="itest-1")
    if response.status_code != 401:
        raise IntegrationCheckError("Error handler: AuthenticationFailed must map to 401")
    if "no token" not in response.body["error"]["message"]:
        raise IntegrationCheckError("Error handler: 4xx messages should be client-visible")
    return "AuthenticationFailed -> 401 envelope OK"


def _check_rate_limiter_and_ip_whitelist_wire_up() -> str:
    from gateway.gateway_config import load_gateway_config
    from gateway.ip_whitelist import IPWhitelist
    from gateway.rate_limiter import RateLimiter

    cfg = load_gateway_config()
    limiter = RateLimiter(requests_per_minute=cfg.rate_limit_per_minute, burst=cfg.rate_limit_burst)
    limiter.check("integration-check-client")

    whitelist = IPWhitelist(cfg)
    whitelist.is_allowed("127.0.0.1")  # exercises the code path; does not assert allow/deny
    return "RateLimiter and IPWhitelist construct from GatewayConfig without error"


def _check_metrics_and_health_pipeline() -> str:
    from deployment.health_check import default_health_checker
    from monitoring.metrics import get_metrics

    get_metrics().record_request("integration-check", 12.5, is_error=False)
    result = default_health_checker().run()
    if "gateway_config_loaded" not in result.checks:
        raise IntegrationCheckError("Health checker missing gateway_config_loaded check")
    return f"health checks: {result.checks}"


def _check_catalyst_json_function_contract() -> str:
    config_path = PROJECT_ROOT / "catalyst.json"
    config = json.loads(config_path.read_text())

    fn_names = {fn["name"] for fn in config.get("functions", [])}
    required = {"core-crud-api", "analytics-api", "realtime-refresh-cron"}
    missing = required - fn_names
    if missing:
        raise IntegrationCheckError(f"catalyst.json missing declared functions: {missing}")

    gw = config.get("api_gateway", {})
    for flag in ("https_only", "jwt_auth", "rate_limiting", "ip_whitelisting"):
        if not gw.get(flag):
            raise IntegrationCheckError(f"catalyst.json api_gateway.{flag} must be enabled")

    return f"functions declared: {sorted(fn_names)}"


def _check_member2_table_naming_contract() -> str:
    """
    Informational only: records the DataStore lookup-table names Member 2
    owns, so naming drift between their generators and Member 4's ZCQL
    queries is visible in one place. Does not touch a live DataStore.
    """
    return f"{len(EXPECTED_MEMBER2_LOOKUP_TABLES)} lookup tables expected from Member 2: " + ", ".join(
        EXPECTED_MEMBER2_LOOKUP_TABLES
    )


def _check_member4_endpoint_auth_contract() -> str:
    """
    Informational only: the auth mode each Member 4 endpoint should use,
    per docs/API_SECURITY.md. Member 4's route file is the source of truth —
    this just gives one place to diff against.
    """
    jwt_count = sum(1 for mode in EXPECTED_MEMBER4_ENDPOINTS.values() if mode == "jwt")
    return f"{len(EXPECTED_MEMBER4_ENDPOINTS)} endpoints expected ({jwt_count} JWT, 1 api_key, 1 none)"


CHECKS: list[tuple[str, Callable[[], str]]] = [
    ("gateway_config", _check_gateway_config_loads),
    ("secrets_manager", _check_secrets_configured),
    ("jwt_roundtrip", _check_jwt_issue_and_validate_roundtrip),
    ("rbac_matrix", _check_rbac_permission_matrix),
    ("auth_middleware_e2e", _check_auth_middleware_end_to_end),
    ("error_handler", _check_error_handler_wraps_rejections),
    ("rate_limit_ip_whitelist", _check_rate_limiter_and_ip_whitelist_wire_up),
    ("metrics_and_health", _check_metrics_and_health_pipeline),
    ("catalyst_json_contract", _check_catalyst_json_function_contract),
    ("member2_table_naming_contract", _check_member2_table_naming_contract),
    ("member4_endpoint_auth_contract", _check_member4_endpoint_auth_contract),
]


def run(mode: str = "human") -> bool:
    all_passed = True
    for name, check_fn in CHECKS:
        try:
            detail = check_fn()
            if mode == "human":
                print(f"[PASS] {name} — {detail}")
        except Exception as exc:  # noqa: BLE001 - intentional: report every failure, don't stop early
            all_passed = False
            print(f"[FAIL] {name} — {exc}", file=sys.stderr)

    if mode == "human":
        print("\n=== Integration check: " + ("ALL PASSED" if all_passed else "FAILURES ABOVE") + " ===")
    return all_passed


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["human", "ci"], default="human")
    args = parser.parse_args()
    ok = run(args.mode)
    sys.exit(0 if ok else 1)
