"""
Implementation backing the public `GET /api/health` endpoint (see project
plan's API table — no auth required, used by Catalyst monitoring and
uptime checks).
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field

from monitoring.logger import get_logger
from monitoring.metrics import get_metrics

logger = get_logger("health_check")


@dataclass
class HealthCheckResult:
    healthy: bool
    checks: dict[str, bool] = field(default_factory=dict)
    metrics_summary: dict[str, dict[str, float]] = field(default_factory=dict)
    checked_at: float = field(default_factory=time.time)


class HealthChecker:
    """
    Runs a set of lightweight dependency checks. Each check is a zero-arg
    callable returning True/False; failures are caught and treated as False
    rather than raising, so one broken dependency doesn't crash the health
    endpoint itself.
    """

    def __init__(self) -> None:
        self._checks: dict[str, Callable[[], bool]] = {}

    def register(self, name: str, check_fn: Callable[[], bool]) -> None:
        self._checks[name] = check_fn

    def run(self) -> HealthCheckResult:
        results: dict[str, bool] = {}
        for name, check_fn in self._checks.items():
            try:
                results[name] = bool(check_fn())
            except Exception:
                logger.error("health_check.failed", check=name, exc_info=True)
                results[name] = False

        overall_healthy = all(results.values()) if results else True
        return HealthCheckResult(
            healthy=overall_healthy,
            checks=results,
            metrics_summary=get_metrics().snapshot(),
        )


def default_health_checker() -> HealthChecker:
    """
    Health checker wired with the checks relevant to Member 1's scope.
    Member 4 can register additional checks (DataStore connectivity, ML
    cache freshness) without modifying this module.
    """
    checker = HealthChecker()
    checker.register("gateway_config_loaded", _check_gateway_config)
    checker.register("secrets_configured", _check_secrets_configured)
    return checker


def _check_gateway_config() -> bool:
    from gateway.gateway_config import load_gateway_config

    config = load_gateway_config()
    return config.rate_limit_per_minute > 0


def _check_secrets_configured() -> bool:
    from security.secrets_manager import MissingSecretError, SecretsManager

    try:
        SecretsManager().get_jwt_secret()
        return True
    except MissingSecretError:
        return False
