"""
Deployment orchestration helper wrapping the Catalyst CLI.

This does not reimplement Catalyst's CLI; it sequences the standard
commands (`catalyst init`, `catalyst serve`, `catalyst deploy`) with the
pre-flight validation the project plan's "Final Validation" checklist calls
for, and fails fast with a clear message rather than deploying a broken
build.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
REQUIRED_FILES = ["catalyst.json", "requirements.txt", ".env.example"]


class DeploymentPreflightError(Exception):
    """Raised when pre-deployment validation fails."""


def _check_catalyst_cli_available() -> None:
    if shutil.which("catalyst") is None:
        raise DeploymentPreflightError(
            "Catalyst CLI not found on PATH. Install it with: npm install -g zcatalyst-cli"
        )


def _check_required_files() -> None:
    missing = [name for name in REQUIRED_FILES if not (PROJECT_ROOT / name).exists()]
    if missing:
        raise DeploymentPreflightError(f"Missing required files: {', '.join(missing)}")


def _check_catalyst_json_valid() -> None:
    config_path = PROJECT_ROOT / "catalyst.json"
    try:
        with config_path.open() as fh:
            config = json.load(fh)
    except json.JSONDecodeError as exc:
        raise DeploymentPreflightError(f"catalyst.json is not valid JSON: {exc}") from exc

    if "functions" not in config or not config["functions"]:
        raise DeploymentPreflightError("catalyst.json declares no functions")


def _check_env_file_not_committed() -> None:
    env_path = PROJECT_ROOT / ".env"
    gitignore_path = PROJECT_ROOT / ".gitignore"
    if env_path.exists() and gitignore_path.exists():
        gitignore_content = gitignore_path.read_text()
        if ".env" not in gitignore_content:
            raise DeploymentPreflightError(".env exists but is not excluded in .gitignore")


def run_preflight_checks() -> None:
    """Run every pre-deployment check; raises DeploymentPreflightError on first failure."""
    checks = [
        _check_catalyst_cli_available,
        _check_required_files,
        _check_catalyst_json_valid,
        _check_env_file_not_committed,
    ]
    for check in checks:
        check()


_ALLOWED_ENVIRONMENTS = ("development", "production")


def deploy(environment: str = "development") -> int:
    """
    Run preflight checks, then invoke `catalyst deploy` targeting the given
    environment. Returns the subprocess exit code.
    """
    if environment not in _ALLOWED_ENVIRONMENTS:
        print(
            f"[preflight-failed] Unknown environment '{environment}'. "
            f"Must be one of: {', '.join(_ALLOWED_ENVIRONMENTS)}",
            file=sys.stderr,
        )
        return 1

    try:
        run_preflight_checks()
    except DeploymentPreflightError as exc:
        print(f"[preflight-failed] {exc}", file=sys.stderr)
        return 1

    catalyst_bin = shutil.which("catalyst")
    if catalyst_bin is None:
        print("[preflight-failed] Catalyst CLI not found on PATH.", file=sys.stderr)
        return 1

    print(f"[preflight-passed] Deploying to '{environment}' environment...")
    result = subprocess.run(  # noqa: S603 - args are a fixed list plus a validated enum value
        [catalyst_bin, "deploy", "--target", environment],
        cwd=str(PROJECT_ROOT),
        check=False,
    )
    return result.returncode


if __name__ == "__main__":
    target_env = sys.argv[1] if len(sys.argv) > 1 else "development"
    sys.exit(deploy(target_env))
