#!/usr/bin/env bash
# ==========================================================
# One-time Zoho Catalyst project initialization.
# Usage: ./scripts/init_catalyst.sh
# ==========================================================
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${PROJECT_ROOT}"

if ! command -v catalyst &> /dev/null; then
  echo "Catalyst CLI not found. Installing globally via npm..."
  npm install -g zcatalyst-cli
fi

echo "-> Logging in to Zoho Catalyst (opens browser)..."
catalyst login

echo "-> Initializing Catalyst project in this directory..."
catalyst init

echo "-> Adding development and production environments..."
catalyst environment:add --name development || true
catalyst environment:add --name production || true

echo "-> Enabling required Catalyst components..."
catalyst components:enable datastore
catalyst components:enable functions
catalyst components:enable api-gateway

echo "=== Catalyst project initialized. Next: run scripts/setup_env.sh ==="
