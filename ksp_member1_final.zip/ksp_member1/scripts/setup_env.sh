#!/usr/bin/env bash
# ==========================================================
# Local development environment bootstrap.
# Usage: ./scripts/setup_env.sh
# ==========================================================
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${PROJECT_ROOT}"

echo "-> Creating virtual environment (.venv)..."
python3 -m venv .venv
source .venv/bin/activate

echo "-> Installing dependencies..."
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet

if [[ ! -f ".env" ]]; then
  echo "-> Creating .env from .env.example..."
  cp .env.example .env
  echo "   Edit .env and fill in real secret values before running the app."
else
  echo "-> .env already exists, leaving it untouched."
fi

echo "-> Generating a local development JWT secret (if not already set)..."
python3 scripts/generate_secrets.py --if-missing

echo "=== Environment ready. Activate with: source .venv/bin/activate ==="
