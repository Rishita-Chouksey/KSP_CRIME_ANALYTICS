"""
Entry point for the Catalyst Cron Function declared in catalyst.json
(`realtime-refresh-cron`). The actual ML recalculation logic belongs to
Member 3/4; this module owns the *operational* wrapper: locking, timing,
structured logging, and failure alerting, so a slow or failing ML refresh
degrades gracefully instead of silently corrupting the AnalyticsCache table.
"""

from __future__ import annotations

import time
from collections.abc import Callable

from monitoring.logger import get_logger
from monitoring.metrics import get_metrics

logger = get_logger("refresh_cache")

# Member 3/4 register their real recalculation callables here at import time,
# e.g. `refresh_cache.register("hotspots", recompute_hotspots)`.
_REFRESH_JOBS: dict[str, Callable[[], None]] = {}


def register(name: str, job_fn: Callable[[], None]) -> None:
    _REFRESH_JOBS[name] = job_fn


def run() -> dict[str, str]:
    """
    Catalyst Cron entry point (matches `entry_point: scripts/refresh_cache.run`
    in catalyst.json). Runs every registered refresh job, isolating failures
    so one broken ML module doesn't block the others from refreshing.
    """
    results: dict[str, str] = {}
    metrics = get_metrics()

    for name, job_fn in _REFRESH_JOBS.items():
        started_at = time.perf_counter()
        try:
            job_fn()
            results[name] = "success"
        except Exception:
            results[name] = "failed"
            logger.error("refresh_job.failed", job=name, exc_info=True)
        finally:
            duration_ms = (time.perf_counter() - started_at) * 1000
            metrics.record_request(f"cron.{name}", duration_ms, is_error=results[name] == "failed")

    logger.info("refresh_cache.completed", results=results)
    return results


if __name__ == "__main__":
    run()
