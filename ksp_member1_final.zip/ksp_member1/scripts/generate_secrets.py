"""
Generates a cryptographically strong local JWT secret for development use
and writes it into `.env` (never into `.env.example`, which stays a
committed template with placeholder values only).

Usage:
    python scripts/generate_secrets.py                # always overwrite
    python scripts/generate_secrets.py --if-missing    # only write if unset/placeholder
"""

from __future__ import annotations

import argparse
import secrets
from pathlib import Path

ENV_PATH = Path(__file__).resolve().parent.parent / ".env"


def _read_env_lines() -> list[str]:
    if not ENV_PATH.exists():
        raise SystemExit(f"{ENV_PATH} does not exist. Run scripts/setup_env.sh first.")
    return ENV_PATH.read_text().splitlines()


def _current_value(lines: list[str], key: str) -> str | None:
    for line in lines:
        if line.startswith(f"{key}="):
            return line.split("=", 1)[1]
    return None


def _set_value(lines: list[str], key: str, value: str) -> list[str]:
    found = False
    new_lines = []
    for line in lines:
        if line.startswith(f"{key}="):
            new_lines.append(f"{key}={value}")
            found = True
        else:
            new_lines.append(line)
    if not found:
        new_lines.append(f"{key}={value}")
    return new_lines


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--if-missing",
        action="store_true",
        help="Only generate if the current value is empty or a placeholder",
    )
    args = parser.parse_args()

    lines = _read_env_lines()
    current = _current_value(lines, "JWT_SECRET_KEY")

    should_generate = not args.if_missing or not current or current.startswith("replace_with")
    if not should_generate:
        print("JWT_SECRET_KEY already set; leaving untouched (use without --if-missing to force).")
        return

    new_secret = secrets.token_urlsafe(64)
    updated_lines = _set_value(lines, "JWT_SECRET_KEY", new_secret)
    ENV_PATH.write_text("\n".join(updated_lines) + "\n")
    print("Generated a new JWT_SECRET_KEY and wrote it to .env")


if __name__ == "__main__":
    main()
